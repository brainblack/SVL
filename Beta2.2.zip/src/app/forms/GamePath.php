<?php
namespace app\forms;

use bundle\windows\Registry;
use bundle\windows\Windows;
use php\lib\fs;
use std, gui, framework, app;


class GamePath extends AbstractForm
{

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null)
    {
        $game_path = $this->edit->text; // НЕ ТРОГАТЬ
        if(fs::isFile("$game_path")) // НЕ ТРОГАТЬ
        {
            if(fs::exists("$game_path")) // НЕ ТРОГАТЬ
            {
                Registry::of('HKEY_CURRENT_USER\Software\SVL')->add('game_path', $game_path); // НЕ ТРОГАТЬ
                app()->hideForm('GamePath'); // НЕ ТРОГАТЬ
                app()->showForm('MainForm'); // НЕ ТРОГАТЬ
            }
            else UXDialog::show('Выберите путь к игре!'); // НЕ ТРОГАТЬ      
        }
        else UXDialog::show('Выберите путь к игре!'); // НЕ ТРОГАТЬ
    }

    /**
     * @event show 
     */
   /** function doShow(UXWindowEvent $e = null)
    {    
        $game_path = Registry::of('HKEY_CURRENT_USER\Software\SVL')->read('game_path'); // НЕ ТРОГАТЬ
        if($game_path) app()->hideForm('GamePath'); app()->showForm('MainForm'); // НЕ ТРОГАТЬ
    }

    /**
     * @event toggleButton.mouseDown-Left 
     */
    function doToggleButtonMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }


}