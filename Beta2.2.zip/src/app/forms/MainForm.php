<?php
namespace app\forms; // НЕ ТРОГАТЬ


use bundle\windows\Registry; // НЕ ТРОГАТЬ
use bundle\windows\Windows; // НЕ ТРОГАТЬ
use std, gui, framework, app; // НЕ ТРОГАТЬ
use php\compress\ZipFile;
use php\lib\fs;

class MainForm extends AbstractForm
{
    /**
     * @event show 
     */    
    function doShow(UXWindowEvent $e = null) // При открытии
    {
        $nick_name = Registry::of('HKEY_CURRENT_USER\Software\SAMP')->read('PlayerName')->value; // НЕ ТРОГАТЬ
        Element::setText($this->edit, $nick_name); // НЕ ТРОГАТЬ
        
        $game_path = Registry::of('HKEY_CURRENT_USER\Software\SAMP')->read('game_path')->value; // НЕ ТРОГАТЬ
        if($game_path) // НЕ ТРОГАТЬ
            return Element::setText($this->label3, 'Путь указан'); // НЕ ТРОГАТЬ
    }



    /**
     * @event buttonAlt.click-Left 
     */
    function doButtonAltClickLeft(UXMouseEvent $e = null) // Играть
    {
        $ip = '176.32.39.131'; // Ваш IP адрес
        $port = '7777'; // Порт вашего IP адреса
        
        $game_path = Registry::of('HKEY_CURRENT_USER\Software\SAMP')->read('game_path')->value; // НЕ ТРОГАТЬ
        $PlayerName = $this->edit->text; // НЕ ТРОГАТЬ
        
        Registry::of('HKEY_CURRENT_USER\Software\SAMP')->add('PlayerName', $PlayerName); // НЕ ТРОГАТЬ
        execute("$game_path $ip:$port", false); // НЕ ТРОГАТЬ
        app()->shutdown(); // НЕ ТРОГАТЬ
    }

    /**
     * @event button.click-Left 
     */
    function doButtonClickLeft(UXMouseEvent $e = null) // ВКонтакте
    {
        browse('https://vk.com/maks_grant'); // укажите ссылку на вашу группу
    }

    /**
     * @event button3.click-Left 
     */
    function doButton3ClickLeft(UXMouseEvent $e = null) // Сайт
    {    
        browse('https://samp-vl.su/'); // укажите ссылку на ваш сайт
    }

    
    /**
     * @event button5.click-Left 
     */
    function doButton5ClickLeft(UXMouseEvent $e = null) // Форум
    {    
        browse('https://forum.samp-vl.su/'); // укажите ссылку на ваш форум
    }

    /**
     * @event toggleButton.click-Left 
     */
    function doToggleButtonClickLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event toggleButtonAlt.mouseDown-Left 
     */
    function doToggleButtonAltMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button4.click-Left 
     */

    /**
     * @event button6.action 
     */
    function doButton6Action(UXEvent $e = null)
    {    
        $this->form('GamePath')->show();
    }

    /**
     * @event button4.click-Left 
     */
    function doButton4ClickLeft(UXMouseEvent $e = null)
    {    
        $this->downloader->start();
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {    
        $dir = new File("./SVL");
        $dir->mkdirs();
    }



    /**
     * @event button8.mouseDown-Left 
     */



}
    /**
     * @event button7_downloader.click-Left 
     */
    /**function doButton8ClickLeft(UXMouseEvent $e = null)
    {    
        $zipFile = new ZipFile('test2.zip');
        $zipFile->unpack('./');
        }
    }
