<?php
namespace app\modules;

use php\compress\ZipFile;
use httpclient;
use std, gui, framework, app;
use ZipFileScript, zipFile;

class MainModule extends AbstractModule
{

    /**
     * @event downloader.successAll 
     */
    function doDownloaderSuccessAll(ScriptEvent $e = null)
    {    
        $zipFile = new ZipFile('GTA.zip');
        $zipFile->unpack('./SVL');
    }

    /**
     * @event downloader.progress 
     */
    function doDownloaderProgress(ScriptEvent $e = null)
    {    
        $percent = round($event->progress * 100 / $event->max, 2);
        
        $this->progressBar->progressK = $event->progress / $event->max;
        $this->speedLabel->text = round($this->downloader->speed / 1024) . " Kb/s";
        $this->speedLabel->show();
        
        $this->fileNameLabel->text = $event->file . " (" . $percent . "%)";
        $this->fileNameLabel->show();
        
        $this->sizeLabel->text = round($event->max / 1024 / 1024, 2) . " Mb";
        $this->sizeLabel->show();
    }

    /**
     * @event zipFile.unpack 
     */









    /**
     * @event downloaderTest2.successAll 
     */



    /**
     * @event zipFile.unpack 
     */

}
