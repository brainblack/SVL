<?php
namespace app\modules;

use std, gui, framework, app;


class GamePath extends AbstractModule
{


}
