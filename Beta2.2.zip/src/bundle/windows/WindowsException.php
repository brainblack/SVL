<?php
namespace bundle\windows;

/**
 * Класс исключения, выбрасываемого функциями пакета Windows
 * @packages windows
 */
class WindowsException extends \Exception{}